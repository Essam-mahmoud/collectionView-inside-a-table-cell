//
//  Constants.swift
//  CollectionInsideTableCellDemo
//
//  Created by Mostafa Mohamed on 10/26/18.
//  Copyright © 2018 Mostafa Mohamed. All rights reserved.
//

import Foundation


enum CellType {
    case shop
    case category
    case item
}
